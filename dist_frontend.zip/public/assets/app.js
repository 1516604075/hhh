
(function(){
  const $ = (q)=>document.querySelector(q);
  const DEFAULT_CONFIG = window.__APP_DEFAULT__ || {
    topTitle:'大将军', topSubtitle:'战力 UR', avatar:'./assets/avatar.png',
    resources:{gold:600,jade:31480},
    backgrounds:{home:'./assets/bg-home.jpg',recycle:'./assets/bg-recycle.jpg',withdraw:'./assets/bg-withdraw.jpg',mine:'./assets/bg-mine.jpg'},
    homeButtons:[{title:'充值',icon:'./assets/btn.png'},{title:'新服馈赠',icon:'./assets/btn.png'},{title:'天命千抽',icon:'./assets/btn.png'},{title:'超值首充',icon:'./assets/btn.png'},{title:'商城',icon:'./assets/btn.png'},{title:'演武场',icon:'./assets/btn.png'}],
    download:{text:'立即下载游戏',link:'#'},
    recycleLongImage:'./assets/recycle-long.png',
    withdraw:{balance:0,min:10,note:'可在后台配置说明文字'},
    mineButtons:[{title:'设置',icon:'./assets/btn.png'},{title:'客服',icon:'./assets/btn.png'}]
  };

  async function getCfg(){
    try{
      const r = await fetch('./config.json?v='+Date.now()); if(r.ok) return await r.json();
    }catch(e){}
    return DEFAULT_CONFIG;
  }

  function applyBg(k){
    const bg = (window._cfg.backgrounds||{})[k];
    if(bg) document.querySelector('.page').style.backgroundImage = "url('"+bg+"')";
  }

  function renderHome(){
    $('#playerTitle').innerText = window._cfg.topTitle || '大将军';
    $('#playerTag').innerText = window._cfg.topSubtitle || '战力 UR';
    $('#goldVal').innerText = (window._cfg.resources&&window._cfg.resources.gold)||0;
    $('#jadeVal').innerText = (window._cfg.resources&&window._cfg.resources.jade)||0;
    if(window._cfg.avatar) $('#avatar').src = window._cfg.avatar;
    const wrap = document.getElementById('homeButtons'); if(wrap){ wrap.innerHTML=''; (window._cfg.homeButtons||[]).slice(0,6).forEach(b=>{ const d=document.createElement('div'); d.className='btn-card'; const i=document.createElement('img'); i.src=b.icon||'./assets/btn.png'; const t=document.createElement('div'); t.className='btn-title'; t.innerText=b.title||'按钮'; d.appendChild(i); d.appendChild(t); d.onclick=()=>{ if(b.content) alert(b.title+'\n\n'+b.content); }; wrap.appendChild(d); });}
    const dl = document.getElementById('dlBtn'); if(dl){ dl.innerText=(window._cfg.download&&window._cfg.download.text)||'立即下载'; dl.href=(window._cfg.download&&window._cfg.download.link)||'#';}
    applyBg('home');
  }

  function renderRecycle(){ applyBg('recycle'); const im=document.getElementById('recycleLongImage'); if(im && window._cfg.recycleLongImage) im.src=window._cfg.recycleLongImage; }
  function renderWithdraw(){ applyBg('withdraw'); const b=(window._cfg.withdraw||{}); const bal=document.getElementById('withdrawBalance'); if(bal) bal.innerText=b.balance||0; const nt=document.getElementById('withdrawNote'); if(nt) nt.innerText=b.note||'提现规则说明'; const s=document.getElementById('withdrawSubmit'); if(s) s.onclick=()=>{ const min=b.min||10; const num=+((document.getElementById('withdrawAmount')||{}).value||0); if(num<min){alert('最低提现门槛：'+min);return;} if(num>(b.balance||0)){alert('余额不足');return;} alert('已提交提现：'+num); }; }
  function renderMine(){ applyBg('mine'); const list=document.getElementById('mineButtons'); if(list){ list.innerHTML=''; (window._cfg.mineButtons||[]).forEach(b=>{ const d=document.createElement('div'); d.className='btn-card'; const i=document.createElement('img'); i.src=b.icon||'./assets/btn.png'; const t=document.createElement('div'); t.className='btn-title'; t.innerText=b.title||'功能'; d.appendChild(i); d.appendChild(t); d.onclick=()=>{ if(b.content) alert(b.title+'\n\n'+b.content); }; list.appendChild(d); }); } }

  (async function(){
    window._cfg = await getCfg();
    const p = location.pathname;
    if(p.endsWith('recycle.html')) renderRecycle();
    else if(p.endsWith('withdraw.html')) renderWithdraw();
    else if(p.endsWith('mine.html')) renderMine();
    else renderHome();
  })();
})();